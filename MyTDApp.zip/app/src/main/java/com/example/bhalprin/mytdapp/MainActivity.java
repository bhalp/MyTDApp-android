package com.example.bhalprin.mytdapp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Pattern;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Message;
import android.preference.ListPreference;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;

import android.content.ContentResolver;
import android.database.Cursor;

import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.util.SparseArray;
import java.util.ArrayList;
import android.util.Log;

//import android.widget.TextView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Environment;

import android.widget.ExpandableListView;
import android.app.AlertDialog;
import android.content.DialogInterface;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private Handler handler = new Handler();

    public static NotificationManagerCompat notificationManager;

    public static final int WEBVIEW_REQUEST = 6;

    public boolean mbCanGetLocation = false;

    private Integer iPermissionsNeeded = 0;

    public static final Integer ACCESS_FINE_LOCATION_PERMISSION_NEEDED = 4;
    public static final Integer ACCESS_COURSE_LOCATION_PERMISSION_NEEDED = 8;
    public static final Integer SEND_SMS_PERMISSION_NEEDED = 2;
    public static final Integer RECEIVE_SMS_PERMISSION_NEEDED = 16;

    public static final int MENU_LOGOUT_IDX = 0;
    public static final int MENU_SETTINGS_IDX = 1;

    public static int giMessageID = 1;
    public static DisplayMetrics dm = new DisplayMetrics();
    public static Context context;

    public static final String TAG = "MainActivity";

    public static final String DefaultRedirectUrl = "https://bhalp.github.io/mySite/defaultCell.htm";
    public static final String APIKey = "5V5GTTHEURLAUGI2JAFC06QKAIVPAVYF";

    private WebView webview;
    private String gsRefreshCode = "";
    private String gsExpirationDate = "";
    private String gsRefreshExpirationDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TimeUtil tu = new TimeUtil();
        context = this;

        android.view.Display mDisplay= this.getWindowManager().getDefaultDisplay();
        mDisplay.getMetrics(dm);
        Log.d("MainActivity - onCreate",  "widthPixels = " + ((Integer)dm.widthPixels).toString());

        notificationManager = NotificationManagerCompat.from(this);

        if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += ACCESS_FINE_LOCATION_PERMISSION_NEEDED;
            };
        } else {
            mbCanGetLocation = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += ACCESS_COURSE_LOCATION_PERMISSION_NEEDED;
            };
        } else {
            mbCanGetLocation = true;
        }

        webview =(WebView)findViewById(R.id.webView);
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        if (iPermissionsNeeded > 0) {
            Log.d("MainActivity - onCreate",  "iPermissionsNeeded = " + iPermissionsNeeded.toString());
        } else {
            if (ConnectivityHelper.isConnectedToNetwork(this)) {

                webview.setWebViewClient(new WebViewClient());
                webview.getSettings().setJavaScriptEnabled(true);
                webview.getSettings().setDomStorageEnabled(true);
                webview.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

                webview.getSettings().setSupportZoom(true);
                webview.getSettings().setBuiltInZoomControls(true);
                webview.getSettings().setDisplayZoomControls(false);

                // Enable responsive layout
                webview.getSettings().setUseWideViewPort(true);
                // Zoom out if the content width is greater than the width of the viewport
                webview.getSettings().setLoadWithOverviewMode(true);

                // Configure the client to use when opening URLs
                webview.setWebViewClient(new WebViewClient());
                webview.setWebChromeClient(new WebChromeClient());

                // Force links and redirects to open in the WebView instead of in a browser
                webview.setWebViewClient(new WebViewClient() {

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        String sUrl[];
                        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                        if (url.startsWith(sharedPref.getString("redirect_url", DefaultRedirectUrl))) {
                            sUrl = url.split(Pattern.quote("code="));

                            Log.i(TAG, "TD Code:" + sUrl[1]);
                            try {
                                Log.i(TAG, "TD Code:" + URLDecoder.decode(sUrl[1],"utf8"));
                                DoTDFormPost doDoTDFormPost = new DoTDFormPost();
                                doDoTDFormPost.execute(sUrl[1]);

                                //view.loadUrl("http://bobsanping.homeip.net:84/tdapp/default.asp?code=" + sUrl[1] );
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            return true;
                        } else {
                            return false;
                        }

                    }
                });
                getLastLoginInfo();
                if (!gsRefreshCode.equals("")) {
                    //have a refresh code - now check to see if it has expired
                    if (tu.CurrentUTCDateTimeAddMinutes(0).compareTo(gsRefreshExpirationDate) < 0  ) {
                        //not expired - so use it
                        String sTDUrl = sharedPref.getString("redirect_url", DefaultRedirectUrl);
//                            String sTDUrl = "http://" + sharedPref.getString("main_db_server_name", "") +
//                                    ":" + sharedPref.getString("main_db_server_port", "82") + "/tdapp/default.asp";
                        try {
                            sTDUrl = sTDUrl + "?expirationTime=" + URLEncoder.encode(gsExpirationDate, "UTF-8");
                            sTDUrl = sTDUrl + "&refreshToken=" + URLEncoder.encode(gsRefreshCode, "UTF-8");
                            sTDUrl = sTDUrl + "&api=2";
                            //uncomment the following to show in browser so can print
//                            try {
//                                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(sTDUrl));
//                                startActivity(myIntent);
//                            } catch (ActivityNotFoundException e) {
//                                Toast.makeText(this, "No application can handle this request."
//                                        + " Please install a webbrowser",  Toast.LENGTH_LONG).show();
//                                e.printStackTrace();
//                            }

                            webview.loadUrl(sTDUrl);
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                    } else {
                        //expired - so need to login again
                        doLogout();
                    }

                } else {
                    webview.clearCache(true);
                    try {
                        webview.loadUrl("https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=" + URLEncoder.encode(sharedPref.getString("redirect_url", DefaultRedirectUrl), "UTF-8") + "&client_id=" + APIKey + "%40AMER.OAUTHAP");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                Toast.makeText(this, getString(R.string.not_connected_to_network),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d ("MainActivity", "onDestroy");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d ("MainActivity", "onStop");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        int idxResult = 0;
        if ((requestCode & ACCESS_FINE_LOCATION_PERMISSION_NEEDED) == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanGetLocation = true;
            }
            idxResult++;
        }
        if ((requestCode & ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanGetLocation = true;
            }
            idxResult++;
        }
        return;
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        if (iPermissionsNeeded > 0) {
            String sPermissonsList = "";
            String sSep = "";
            if ((iPermissionsNeeded & ACCESS_FINE_LOCATION_PERMISSION_NEEDED) == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.ACCESS_FINE_LOCATION;
                sSep = "|";
            }
            if ((iPermissionsNeeded & ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.ACCESS_COARSE_LOCATION;
                sSep = "|";
            }

            if (!sPermissonsList.equals("")) {
                String sPermissions [] = sPermissonsList.split(Pattern.quote("|"));
                ActivityCompat.requestPermissions(this,
                        sPermissions,
                        iPermissionsNeeded);
           }

            iPermissionsNeeded = 0;
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu) {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        if (ConnectivityHelper.isConnectedToNetwork(this)) {
            if (gsRefreshCode.equals("")) {
                menu.getItem(MENU_LOGOUT_IDX).setVisible(false);
                menu.getItem(MENU_SETTINGS_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_LOGOUT_IDX).setVisible(true);
                menu.getItem(MENU_SETTINGS_IDX).setVisible(false);
            }
        } else {
            menu.getItem(MENU_LOGOUT_IDX).setVisible(false);
            menu.getItem(MENU_SETTINGS_IDX).setVisible(true);
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == WEBVIEW_REQUEST) {
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

//        // Checks the orientation of the screen
//        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
//        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
//            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
//        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        RelativeLayout main_view = (RelativeLayout) findViewById(R.id.main_view);
        //final WebView webView = (WebView)findViewById(R.id.webView);
        switch (item.getItemId())
        {
            case R.id.menu_logout: {
                doLogout();
                invalidateOptionsMenu();
                return true;
            }

            case R.id.menu_settings: {
//                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
//                Toast.makeText(this, "DB Server = " + sharedPref.getString("main_db_server_name", ""),
//                       Toast.LENGTH_SHORT).show();

                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);
                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void doLogout () {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        LastLogin lastLogin = new LastLogin();
        updateLastLoginInfo(lastLogin);
        gsRefreshCode = "";
        gsExpirationDate = "";
        gsRefreshExpirationDate = "";
        webview.clearCache(true);
        try {
            webview.loadUrl("https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=" + URLEncoder.encode(sharedPref.getString("redirect_url", DefaultRedirectUrl), "UTF-8") + "&client_id=" + APIKey + "%40AMER.OAUTHAP");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void getLastLoginInfo () {
        MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
        LastLogin lastlogin = dbHandler.findLastLogin();
        if (lastlogin != null)
        {
            gsRefreshCode = lastlogin.getRefreshToken();
            gsExpirationDate = lastlogin.getAccessTokenExpirationDate();
            gsRefreshExpirationDate = lastlogin.getRefreshTokenExpirationDate();
        } else {
            gsRefreshCode = "";
            gsExpirationDate = "";
            gsRefreshExpirationDate = "";
        }

    }

    public void updateLastLoginInfo (LastLogin lastlogin) {
        MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
        dbHandler.updateLastLogin(lastlogin);
    }


    public class DoTDFormPost extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            if (!(r.equals(""))) {

                TimeUtil tu = new TimeUtil();
                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
//                String sTDUrl = "http://" + sharedPref.getString("main_db_server_name", "") +
//                        ":" + sharedPref.getString("main_db_server_port", "81") + "/tdapp/default.asp";

//                String sTDUrl = "http://bobsanping.homeip.net:82/tdapp/default.asp";

                try {
                    String sTDUrl = sharedPref.getString("redirect_url", DefaultRedirectUrl);
                    String sLines [] = r.split(Pattern.quote("<<>>"));
//                    sTDUrl = sTDUrl + "?accessToken=" + URLEncoder.encode(sLines[0], "UTF-8");
                    LastLogin lastLogin = new LastLogin();
                    lastLogin.setRefreshToken(sLines[1]);
                    lastLogin.setAccessTokenExpirationDate(sLines[2]);
                    lastLogin.setRefreshTokenExpirationDate(sLines[3]);
//                    lastLogin.setRefreshTokenExpirationDate(tu.CurrentUTCDateTimeAddMinutes(3)); //test expire 3 minutes from now;
                    lastLogin.setRefreshTokenExpirationDate(tu.CurrentUTCDateTimeAddMinutes((Long.parseLong(sLines[3]) / 60) - (60 * 24))); //expiration date is in seconds - change to minutes then subtract a day);
                    gsRefreshCode = lastLogin.getRefreshToken();
                    gsExpirationDate = lastLogin.getAccessTokenExpirationDate();
                    gsRefreshExpirationDate = lastLogin.getRefreshTokenExpirationDate();
                    updateLastLoginInfo(lastLogin);
                    invalidateOptionsMenu();
                    sTDUrl = sTDUrl + "?expirationTime=" + URLEncoder.encode(sLines[2], "UTF-8");
                    sTDUrl = sTDUrl + "&refreshToken=" + URLEncoder.encode(sLines[1], "UTF-8");
                    sTDUrl = sTDUrl + "&api=2";
                    webview.loadUrl(sTDUrl);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        protected String doInBackground(String... params) {

            TimeUtil tu = new TimeUtil();
            String sUserId = "";
            String sAccessToken = "";
            String sRefreshToken = "";
            String sAccessTokenExipirationTime = "";
            String sRefreshTokenExipirationTime = "";
            String code = params[0]; //already urlEncoded
            String sExpireUTCTime = ""; //will be in this format "yyyyMMddHHmmssSSS"
            URL url = null;
            String urlString = "https://api.tdameritrade.com/v1/oauth2/token";
            InputStream stream = null;
            HttpURLConnection urlConnection = null;
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
            try {
                url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);

                String data = URLEncoder.encode("grant_type", "UTF-8")
                        + "=" + URLEncoder.encode("authorization_code", "UTF-8");

                data += "&" + URLEncoder.encode("access_type", "UTF-8") + "="
                        + URLEncoder.encode("offline", "UTF-8");

                data += "&" + URLEncoder.encode("code", "UTF-8") + "="
                        + code;

                data += "&" + URLEncoder.encode("client_id", "UTF-8") + "="
                        + URLEncoder.encode( APIKey, "UTF-8");

                data += "&" + URLEncoder.encode("redirect_uri", "UTF-8") + "="
                        + URLEncoder.encode(sharedPref.getString("redirect_url", DefaultRedirectUrl), "UTF-8");

                urlConnection.connect();

                OutputStreamWriter wr = new OutputStreamWriter(urlConnection.getOutputStream());
                wr.write(data);
                wr.flush();

                stream = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"), 8);

                Integer iNumTX = 0;
                String sHistory = "";
                String result = "";
                String sLine = reader.readLine();
                String sNL = "";
                while (sLine != null) {
                    result = result + sNL + sLine;
//                    sNL = "\n";
                    sLine = reader.readLine();
                }

                //get the access_token to use in future API calls
                String sLines [] = result.split(Pattern.quote("\"access_token\" :"));
                sAccessToken = sLines[1].split(Pattern.quote("\""))[1];

                sLines = result.split("\"refresh_token\" :");
                sRefreshToken = sLines[1].split(Pattern.quote("\""))[1];

                sAccessTokenExipirationTime = (result.split(Pattern.quote("\"expires_in\" : ")))[1].split(Pattern.quote(","))[0];
                sRefreshTokenExipirationTime = (result.split(Pattern.quote("\"refresh_token_expires_in\" : ")))[1].split(Pattern.quote(","))[0];


                result = sAccessToken + "<<>>" + sRefreshToken + "<<>>" + sAccessTokenExipirationTime + "<<>>" + sRefreshTokenExipirationTime;

                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.i("Result", "SLEEP ERROR");
            }
            return null;
        }
    }


}


