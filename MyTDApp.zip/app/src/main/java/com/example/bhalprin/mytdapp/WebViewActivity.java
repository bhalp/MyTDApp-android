package com.example.bhalprin.mytdapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.DownloadListener;
import android.net.Uri;

import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Pattern;

public class WebViewActivity extends AppCompatActivity {

    private static final String TAG = "WebViewActivity";
    public static NotificationManagerCompat notificationManager;

    private boolean bDoingTD = false;

    private WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        notificationManager = NotificationManagerCompat.from(this);

        setContentView(R.layout.activity_web_view);

        webview =(WebView)findViewById(R.id.webView);
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setDomStorageEnabled(true);
        webview.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webview.getSettings().setBuiltInZoomControls(true);
        webview.getSettings().setDisplayZoomControls(false);

        // Enable responsive layout
        webview.getSettings().setUseWideViewPort(true);
        // Zoom out if the content width is greater than the width of the viewport
        webview.getSettings().setLoadWithOverviewMode(true);

        // Configure the client to use when opening URLs
        webview.setWebViewClient(new WebViewClient());
        webview.setWebChromeClient(new WebChromeClient());

        bDoingTD = false;

        // Force links and redirects to open in the WebView instead of in a browser
        webview.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                String sUrl[];
                if(url.toString().contains(".ppt") || url.toString().contains("https://photos.app.goo.gl")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                        boolean canOpen = intent.resolveActivity(getPackageManager()) != null;
                        if (canOpen) {
                            startActivity(intent);
                            return true;
                        } else {
                            //view.loadUrl(url);
                            return false;
                        }
                    } catch (Exception e) {
                        Log.i(TAG, "shouldOverrideUrlLoading Exception:" + e);
                        return true;
                    }

                } else {
                    if (url.startsWith("https://localhost:8080/?code=")) {
                        sUrl = url.split(Pattern.quote("code="));

                        Log.i(TAG, "TD Code:" + sUrl[1]);
                        try {
                            Log.i(TAG, "TD Code:" + URLDecoder.decode(sUrl[1],"utf8"));
                            bDoingTD = true;
                            DoTDFormPost doDoTDFormPost = new DoTDFormPost();
                            doDoTDFormPost.execute(sUrl[1]);

                            //view.loadUrl("http://bobsanping.homeip.net:84/tdapp/default.asp?code=" + sUrl[1] );
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        return false;
                    } else if (url == null || url.startsWith("http://") || url.startsWith("https://")) return false;
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                        boolean canOpen = intent.resolveActivity(getPackageManager()) != null;
                        if (canOpen) {
                            startActivity(intent);
                            return true;
                        } else {
                            //view.loadUrl(url);
                            return false;
                        }
                    } catch (Exception e) {
                        Log.i(TAG, "shouldOverrideUrlLoading Exception:" + e);
                        return true;
                    }
                }

            }
        });


        //for download PDF files
        webview.setDownloadListener(new MyDownLoadListener());
        webview.clearCache(true);

        Intent data = getIntent();
        if (data.hasExtra("url"))
        {
            webview.loadUrl(data.getExtras().getString("url"));
        } else {
            webview.loadUrl("http://bobsanping.homeip.net:81/mileagesite");
        }

        if (data.hasExtra("title"))
        {
            this.setTitle(data.getExtras().getString("title"));
        } else {
            this.setTitle("");
        }

    }

    @Override
    public void onBackPressed() {
        if (bDoingTD) {
            super.onBackPressed();
        } else {
            if (webview.canGoBack())
                webview.goBack();
            else
                super.onBackPressed();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

//        // Checks the orientation of the screen
//        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
//        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
//            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
//        }
    }


    public class MyDownLoadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {

            // Create URI
            Uri uri = Uri.parse(url);

            if (url != null) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                try {
                    startActivity(i);
                } catch (Exception ex) {
                    webview.loadUrl("http://docs.google.com/gview?embedded=true&url=" + url);
                }
            }

        }
    }

    public class DoTDFormPost extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            if (!(r.equals(""))) {
//                Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();

                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(WebViewActivity.this);
                String sTDUrl = "https://bhalp.github.io/mySiteTest/default.htm";
//                String sTDUrl = "http://" + sharedPref.getString("main_db_server_name", "") +
//                        ":" + sharedPref.getString("main_db_server_port", "81") + "/tdapp/default.asp";

//                String sTDUrl = "http://bobsanping.homeip.net:84/tdapp/default.asp";
                //webview.loadUrl(sTDUrl);
                try {
                    String sLines [] = r.split(Pattern.quote("<<>>"));
//                    sTDUrl = sTDUrl + "?accessToken=" + URLEncoder.encode(sLines[0], "UTF-8");
                    sTDUrl = sTDUrl + "?refreshToken=" + URLEncoder.encode(sLines[1], "UTF-8");
                    sTDUrl = sTDUrl + "&expirationTime=" + URLEncoder.encode(sLines[2], "UTF-8");
                    webview.loadUrl(sTDUrl);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }


//                NotificationUtils.GenerateNotification("DoTDFormPost", r,
//                        1, null, false, WebViewActivity.this,
//                        notificationManager, NotificationCompat.PRIORITY_HIGH);



            }
            //MainActivity.this.getLastLoginInfo();

        }

        @Override
        protected String doInBackground(String... params) {

            TimeUtil tu = new TimeUtil();
            String sUserId = "";
            String sAccessToken = "";
            String sRefreshToken = "";
            String sAccessTokenExipirationTime = "";
            String code = params[0]; //already urlEncoded
            String sExpireUTCTime = ""; //will be in this format "yyyyMMddHHmmssSSS"
            URL url = null;
            String urlString = "https://api.tdameritrade.com/v1/oauth2/token";
            InputStream stream = null;
            HttpURLConnection urlConnection = null;
            try {
                url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);

                String data = URLEncoder.encode("grant_type", "UTF-8")
                        + "=" + URLEncoder.encode("authorization_code", "UTF-8");

                data += "&" + URLEncoder.encode("access_type", "UTF-8") + "="
                        + URLEncoder.encode("offline", "UTF-8");

                data += "&" + URLEncoder.encode("code", "UTF-8") + "="
                        + code;

                data += "&" + URLEncoder.encode("client_id", "UTF-8") + "="
                        + URLEncoder.encode("VTBLS2XWYV8HCIHN8JSTSHEZTFZXNI93", "UTF-8");

                data += "&" + URLEncoder.encode("redirect_uri", "UTF-8") + "="
                        + URLEncoder.encode("https://localhost:8080", "UTF-8");

                urlConnection.connect();

                OutputStreamWriter wr = new OutputStreamWriter(urlConnection.getOutputStream());
                wr.write(data);
                wr.flush();

                stream = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"), 8);

                Integer iNumTX = 0;
                String sHistory = "";
                String result = "";
                String sLine = reader.readLine();
                String sNL = "";
                while (sLine != null) {
                    result = result + sNL + sLine;
//                    sNL = "\n";
                    sLine = reader.readLine();
                }

                //get the access_token to use in future API calls
                String sLines [] = result.split(Pattern.quote("\"access_token\" :"));
                sAccessToken = sLines[1].split(Pattern.quote("\""))[1];

                sLines = result.split("\"refresh_token\" :");
                sRefreshToken = sLines[1].split(Pattern.quote("\""))[1];

                sAccessTokenExipirationTime = (result.split(Pattern.quote("\"expires_in\" : ")))[1].split(Pattern.quote(","))[0];


                result = sAccessToken + "<<>>" + sRefreshToken + "<<>>" + sAccessTokenExipirationTime;

                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.i("Result", "SLEEP ERROR");
            }
            return null;
        }
    }
}

