package com.example.bhalprin.mytdapp;

public class LastLogin {
    private int miId;
    private String msRefreshToken = "";
    private String msRefreshTokenExpirationDate = "";
    private String msAccessTokenExpirationDate = "";

    public LastLogin() {

    }

    public LastLogin(int iId, String sRefreshToken, String sRefreshTokenExpirationDate, String sAccessTokenExpirationDate) {
        this.miId = iId;
        this.msRefreshToken = sRefreshToken;
        this.msRefreshTokenExpirationDate = sRefreshTokenExpirationDate;
        this.msAccessTokenExpirationDate = sAccessTokenExpirationDate;
    }

    public int getId() {
        return this.miId;
    }

    public void setId(int iValue) {
        this.miId = iValue;
    }

    public String getRefreshToken() {
        return this.msRefreshToken;
    }

    public void setRefreshToken(String sValue) {
        this.msRefreshToken = sValue;
    }

    public String getRefreshTokenExpirationDate() {
        return this.msRefreshTokenExpirationDate;
    }

    public void setRefreshTokenExpirationDate(String sValue) {
        this.msRefreshTokenExpirationDate = sValue;
    }

    public String getAccessTokenExpirationDate() {
        return this.msAccessTokenExpirationDate;
    }

    public void setAccessTokenExpirationDate(String sValue) {
        this.msAccessTokenExpirationDate = sValue;
    }


}