package com.example.bhalprin.mytdapp;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

public class MyDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 9;
    private static final String DATABASE_NAME = "mytdappDB.db";
    private static final String TABLE_LAST_LOGIN = "lastlogin";

    public static final String COLUMN_LASTLOGIN_ID = "ID";
    public static final String COLUMN_LASTLOGIN_RefreshToken = "RefreshToken";
    public static final String COLUMN_LASTLOGIN_RefreshTokenExpirationDate = "RefreshTokenExpirationDate";
    public static final String COLUMN_LASTLOGIN_AccessTokenExpirationDate = "AccessTokenExpirationDate";

    public static final int COLUMN_LASTLOGIN_ID_IDX = 0;
    public static final int COLUMN_LASTLOGIN_RefreshToken_IDX = 1;
    public static final int COLUMN_LASTLOGIN_RefreshTokenExpirationDate_IDX = 2;
    public static final int COLUMN_LASTLOGIN_AccessTokenExpirationDate_IDX = 3;


    public MyDBHandler(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_LASTLOGIN_TABLE = "CREATE TABLE " +
                TABLE_LAST_LOGIN + "("
                + COLUMN_LASTLOGIN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_LASTLOGIN_RefreshToken + " TEXT collate nocase,"
                + COLUMN_LASTLOGIN_RefreshTokenExpirationDate + " TEXT collate nocase,"
                + COLUMN_LASTLOGIN_AccessTokenExpirationDate + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_LASTLOGIN_TABLE);

        //insert a record into the LASTLOGIN  table showing no one is currently logged in - userid = -1
        ContentValues values = new ContentValues();
        values.put(COLUMN_LASTLOGIN_RefreshToken, "");
        values.put(COLUMN_LASTLOGIN_RefreshTokenExpirationDate, "");
        values.put(COLUMN_LASTLOGIN_AccessTokenExpirationDate, "");

        db.insert(TABLE_LAST_LOGIN, null, values);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LAST_LOGIN);
        onCreate(db);
    }

    public void forceCreate ()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        onUpgrade(db, 0, 0);
    }

    public LastLogin findLastLogin() {
        String query = "Select * FROM " + TABLE_LAST_LOGIN ;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        LastLogin lastlogin = new LastLogin();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            lastlogin.setId(Integer.parseInt(cursor.getString(COLUMN_LASTLOGIN_ID_IDX)));
            lastlogin.setRefreshToken(cursor.getString(COLUMN_LASTLOGIN_RefreshToken_IDX));
            lastlogin.setRefreshTokenExpirationDate(cursor.getString(COLUMN_LASTLOGIN_RefreshTokenExpirationDate_IDX));
            lastlogin.setAccessTokenExpirationDate(cursor.getString(COLUMN_LASTLOGIN_AccessTokenExpirationDate_IDX));
            cursor.close();
        }
        db.close();
        return lastlogin;
    }

    public boolean updateLastLogin(LastLogin lastlogin)
    {
        boolean bOK = false;

        ContentValues values = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        values.put(COLUMN_LASTLOGIN_RefreshToken, lastlogin.getRefreshToken());
        values.put(COLUMN_LASTLOGIN_RefreshTokenExpirationDate, lastlogin.getRefreshTokenExpirationDate());
        values.put(COLUMN_LASTLOGIN_AccessTokenExpirationDate, lastlogin.getAccessTokenExpirationDate());

        bOK = db.update(TABLE_LAST_LOGIN, values, null, null) > 0;

        db.close();
        return bOK;
    }

}
